jQuery(document).ready(function(){
		jQuery(".item .content").mouseenter(function(){
			jQuery(this).find("h2").fadeIn("fast");
		});
		jQuery(".item .content").mouseleave(function(){
			jQuery(this).find("h2").fadeOut("fast");
		});

		jQuery("#me").hover(
			function(){
				jQuery("#me .name").addClass("dark");
				jQuery("#user-menu").slideDown("fast");
			}, 
			function () {
				jQuery("#me .name").removeClass("dark");
				jQuery("#user-menu").slideUp("fast");			
			}
		);
		
		jQuery(".login").click(function(e) {
			jQuery("#loginbox").lightbox_me({
			centered: true, 
			onLoad: function() { 
				jQuery("#loginbox").find("input:first").focus()
				}
			});
			e.preventDefault();
		});
});