<?php

//移除css
function zen_css_alter(&$css) {
    unset($css['modules/user/user.css']);
	unset($css['modules/system/system.theme.css']);
	unset($css['modules/comment/comment.css']);
}
/**
Removes re-sizable functionality on a single text areas
**/
function zen_textarea($variables) {
  $element = $variables['element'];
  element_set_attributes($element, array('id', 'name', 'cols', 'rows'));
  _form_set_class($element, array('form-textarea'));

  $wrapper_attributes = array(
    'class' => array('form-textarea-wrapper'),
  );

  // Add resizable behavior.
  //if (!empty($element['#resizable'])) {
  //  drupal_add_library('system', 'drupal.textarea');
  //  $wrapper_attributes['class'][] = 'resizable';
  //}

  $output = '<div' . drupal_attributes($wrapper_attributes) . '>';
  $output .= '<textarea' . drupal_attributes($element['#attributes']) . '>' . check_plain($element['#value']) . '</textarea>';
  $output .= '</div>';
  return $output;
}

/**
修改评论表单
**/
function zen_form_alter(&$form, $form_state, $form_id)  {
	//drupal_set_message($form_id);
	switch ($form_id)  {
		case 'comment_node_drip_form':
		global $user;
		$form['author']['_author'] = array(
			'#type' => 'item', 
			'#title' => null, 
			'#markup' => theme('user_picture', array('account' => $user)),
		);
		//$form['subject']['#title']= null;
		//$form['comment_body']['und'][0]['#title']= '';
		//$form['comment_body']['und'][0]['#rows'] = 30;
		break;
	}
}

function zen_preprocess_page(&$variables, $hook) {
	if (isset($variables['node'])) {  
    $variables['theme_hook_suggestions'][] = 'page__'. $variables['node']->type;
  }
}