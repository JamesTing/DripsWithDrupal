<?php
/**
 * @file
 * Default theme implementation to display a single Drupal page.
 */
 ?>
 <?php  drupal_add_css(path_to_theme() . '/css/message.css'); ?>

	<div id="header">
		<div class="section clearfix">
		
			<div id="logo">
				<a href="<?php print $front_page; ?>" title="<?php print $site_name; ?>" rel="home" id="logo">
					<img src="<?php print $logo; ?>" alt="<?php print $site_name; ?>" />
				</a>
			</div>
			
			<?php print theme('links__system_main_menu', array('links' => $main_menu, 'attributes' => array('id' => 'navigation', 'class' => array('fleft','clearfix')))); ?>    

			<?php print render($page['header']); ?>

			<?php if ($user->uid) : ?>
			<div id="me">
				<a href="#" class="name"><?php print $user->name; ?></a>
				<div id="user-menu">
					<?php print theme('links__system_secondary_menu', array(
					'links' => $secondary_menu,
					'attributes' => array(
					),
					)); ?>
				</div>
			</div>
			<?php else : ?>
			<div id="me">
				<a href="#" class="name"><?php print t('My account'); ?></a>
				<div id="user-menu">
					<ul>
						<li><?php print l(t('Create new account'), 'user/register');?></li>
						<li><?php print l(t('Log in'), 'user');?></li>
					</ul>
				</div>
			</div>
			<?php endif; ?>
			
		</div>
	</div>

	<?php if ($page['feature']): ?>
		<div id="feature" class="section">
			<?php print render($page['feature']); ?>
		</div>
	<?php endif; ?>

	
    <div id="wrap">
	<div class="inner-wrap">
	<div id="main" class="section clearfix" >
		
			<div id="content" class="corner">
			<?php print $messages; ?>
			<?php if ($title): ?><h1 class="title" id="page-title"><?php print $title; ?></h1><?php endif; ?>
			<?php if ($action_links): ?><ul class="action-links"><?php print render($action_links); ?></ul><?php endif; ?>
			<?php print render($page['content']); ?>     
			</div>
			
			<?php if ($page['sidebar']): ?>
			<div id="sidebar" class="corner">
			  <?php print render($page['sidebar']); ?>
			  <?php print $feed_icons; ?>
			 </div>
			<?php endif; ?>
		</div>
    </div> 
</div>
<div id="footer">
  <?php print render($page['footer']); ?>
</div> 


